package com.akp.examcoach.Basic.Bottomview;

/**
 * Created by Anoop Pandey on 9696381023.
 */
public class Api_Urls {
    public static final String BaseURL = "http://examcoach.in/ExamService.asmx/";
}
