package com.akp.examcoach.Basic.Bottomview;


public class Config {
    // Google Console APIs developer key
    // Replace this key with your's
    public static final String DEVELOPER_KEY = "AIzaSyDltnPfCra1YJtgD8Vvm2l-STNn-c9YBos";

    // YouTube video id
    public static final String YOUTUBE_VIDEO_CODE = "F-V0boyzzQk";
}
