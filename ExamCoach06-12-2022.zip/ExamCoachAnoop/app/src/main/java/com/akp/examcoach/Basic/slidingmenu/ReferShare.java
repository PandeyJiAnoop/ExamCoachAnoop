package com.akp.examcoach.Basic.slidingmenu;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.akp.examcoach.BuildConfig;
import com.akp.examcoach.R;

public class ReferShare extends AppCompatActivity {

    ImageView ivBack;
    private SharedPreferences sharedPreferences;
    String Assoc_UserId,Assoc_Name;
    TextView link_tv;
    TextView share_tv;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refer_share);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        sharedPreferences = getSharedPreferences("asc_login_preference", MODE_PRIVATE);
        Assoc_UserId = sharedPreferences.getString("userid", "");
        Assoc_Name = sharedPreferences.getString("mob", "");
        link_tv=findViewById(R.id.link_tv);
        share_tv=findViewById(R.id.share_tv);

        share_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String shareSubject = "Share Examcoach Application Refer";
                String shareMessage = "Share with your friends and Family Examcoach Your Education Platform " +
                        "Get the Examcoach app from the link below. \nCheers\n\n" +
                        "https://play.google.com/store/apps/details?id=com.akp.examcoach";

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT,
                        "Hey check out my app Examcoach Your Education Platform at: https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID);
                sendIntent.setType("text/plain");
                startActivity(sendIntent);
            }
        });




        ivBack=findViewById(R.id.sliding_menu);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
//        createlink();

    }
   /* public void createlink(){
        Log.e("main", "create link ");
        DynamicLink dynamicLink = FirebaseDynamicLinks.getInstance().createDynamicLink()
                .setLink(Uri.parse("http://retpo.in/"))
                .setDynamicLinkDomain("retpo.page.link")
                // Open links with this app on Android
                .setAndroidParameters(new DynamicLink.AndroidParameters.Builder().build())
                // Open links with com.example.ios on iOS
                //.setIosParameters(new DynamicLink.IosParameters.Builder("com.example.ios").build())
                .buildDynamicLink();
//click -- link -- google play store -- inistalled/ or not  ----
        Uri dynamicLinkUri = dynamicLink.getUri();

        Log.e("main", "  Long refer "+ dynamicLink.getUri());
        //   https://referearnpro.page.link?apn=blueappsoftware.referearnpro&link=https%3A%2F%2Fwww.blueappsoftware.com%2F
        // apn  ibi link
        createReferlink(Assoc_Name, Assoc_UserId);
    }
    public void createReferlink(String custid, String prodid){
        // manuall link
        String sharelinktext  = "http://retpo.page.link/?"+
                "link=http://retpo.in/myrefer.php?custid="+custid +"-"+prodid+
                "&apn="+ getPackageName()+
                "&st="+"Retpo (Use My Refer Link)"+
                "&si="+"http://retpo.in/images/logo-img.png";


        Log.e("mainactivity", "sharelink - "+sharelinktext);
        // shorten the link
        Task<ShortDynamicLink> shortLinkTask = FirebaseDynamicLinks.getInstance().createDynamicLink()
                //.setLongLink(dynamicLink.getUri())    // enable it if using firebase method dynamicLink
                .setLongLink(Uri.parse(sharelinktext))  // manually
                .buildShortDynamicLink()
                .addOnCompleteListener(this, new OnCompleteListener<ShortDynamicLink>() {
                    @Override
                    public void onComplete(@NonNull Task<ShortDynamicLink> task) {
                        if (task.isSuccessful()) {
                            Uri shortLink = task.getResult().getShortLink();
                            Uri flowchartLink = task.getResult().getPreviewLink();
                            link_tv.setText(shortLink.toString());

                            link_tv.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Log.e("main ", "short link "+ shortLink.toString());
                                    // share app dialog
                                    Intent intent = new Intent();
                                    intent.setAction(Intent.ACTION_SEND);
                                    intent.putExtra(Intent.EXTRA_TEXT,  shortLink.toString());
                                    intent.setType("text/plain");
                                    startActivity(intent);
                                }
                            });

                            crdsubmit.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // Short link created


                                    Log.e("main ", "short link "+ shortLink.toString());
                                    // share app dialog
                                    Intent intent = new Intent();
                                    intent.setAction(Intent.ACTION_SEND);
                                    intent.putExtra(Intent.EXTRA_TEXT,  shortLink.toString());
                                    intent.setType("text/plain");
                                    startActivity(intent);
                                }
                            });

                        } else {
                            // Error
                            // ...
                            Log.e("main", " error "+task.getException() );

                        }
                    }
                });

    }*/

}