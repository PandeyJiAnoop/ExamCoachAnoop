package com.akp.examcoach.Basic.QuizExam;

import java.util.ArrayList;
import java.util.HashMap;

public class AppConstants {
    public static final String connectionTimeOut = "Connection Time Out Error";
    public static final String methodget = "GET";
    public static final String projectName = "zozima";
    public static final ArrayList<HashMap<String, String>> addressNewList = new ArrayList();
    public static final ArrayList<HashMap<String, String>> senderInforMationList = new ArrayList();
    public static final ArrayList<HashMap<String, String>> imageList = new ArrayList();

}

